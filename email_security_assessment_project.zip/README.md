# Email & Messaging System Security Assessment

A Windows-friendly Flask project for passive, real-time DNS-based email security assessment, `.eml` header inspection, hardening recommendations, and PDF reporting.

## 1. Requirements
- Windows 10/11
- Python 3.10 or newer
- Internet access for DNS lookups

## 2. Run in VS Code (Windows PowerShell)
Open this folder in VS Code, then open Terminal → New Terminal and run:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

If PowerShell blocks activation, run this once in that terminal:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

Open **http://127.0.0.1:5000** in your browser. Keep the terminal running. Press Ctrl+C to stop.

## 3. Demonstration
1. Enter your guide's email address (or a domain) and click **ANALYSE EMAIL SECURITY**.
2. The app extracts the domain and makes live DNS MX/TXT queries.
3. It checks SPF and DMARC and probes a finite list of common DKIM selectors.
4. It calculates a transparent score from MX (15), SPF (up to 25), DMARC (up to 30), and discovered DKIM selector record (20). This is a configuration indicator, not a message authentication verdict.
5. Download the PDF report.
6. To test header inspection, upload a genuine `.eml` file exported from a mailbox.

## 4. Test cases
- `gmail.com` — commonly has MX, SPF and DMARC records; DKIM selectors may or may not be found by this limited selector list.
- `outlook.com` — test live DNS results; do not assume results are fixed.
- `example.com` — useful comparison domain; its current records are queried live.
- `your-college-domain.edu` — replace with the actual college domain.
- Invalid input such as `not-an-email` — should show a validation error.

DNS results can differ by resolver, network, and time. The app does not hardcode sample records or scores.

## 5. Important technical limitations (explain during viva)
- **Mailbox ownership:** DNS records cannot prove that a person controls an inbox. The optional OTP endpoints only work after configuring a real SMTP service. They send a one-time code and verify the response. Never claim ownership based on DNS alone.
- **DKIM:** There is no universal public DNS mechanism to list every DKIM selector for a domain. The app checks common selector names and labels a miss as *inconclusive*, not proof DKIM is absent. Ask the mail administrator/provider for the actual selector to verify it.
- **SPF/DKIM/DMARC:** DNS record presence is not the same as checking a specific message. Real message authentication is performed by the receiving mail system. `.eml` analysis reads available headers; `Authentication-Results` is trustworthy only if inserted by a trusted receiving system.
- **SMTP:** This project intentionally avoids SMTP brute force, open-relay testing, credential attempts, and sending test/spoofed messages. It performs passive DNS checks only unless the operator separately enables SMTP-backed OTP.
- The score is a simple explainable rubric, not a standards certification or guarantee against phishing.

## 6. Optional OTP setup
OTP delivery is disabled unless valid SMTP settings are supplied as environment variables. Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, and `FLASK_SECRET_KEY` before running the app. The endpoints are `/api/otp/request` (JSON `{ "email": "person@example.com" }`) and `/api/otp/verify` (JSON `{ "email": "...", "code": "123456" }`). Use an app password or dedicated SMTP account, never your personal mailbox password. The UI does not expose OTP controls by default.

## 7. Troubleshooting
- `py` not recognized: install Python from python.org and select **Add Python to PATH**, then reopen VS Code.
- DNS timeout: try another network or DNS resolver; corporate/college networks may restrict DNS.
- Port busy: change `port=5000` near the bottom of `app.py` to `5001`, then use `http://127.0.0.1:5001`.
