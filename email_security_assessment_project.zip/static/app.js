let latest=null;
const $=id=>document.getElementById(id);
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function recordList(items){return items.length?items.map(x=>`<div class="record">${esc(typeof x==="string"?x:JSON.stringify(x))}</div>`).join(""):'<div class="muted">No record returned by DNS.</div>'}
function render(data){
 latest=data;$("results").classList.remove("hidden");$("domain").textContent=data.domain;$("score").textContent=data.score;$("overall").textContent=data.overall;$("checked").textContent="Checked: "+new Date(data.checked_at).toLocaleString();
 $("mx").innerHTML=recordList(data.mx.map(x=>`Priority ${x.priority} · ${x.host}`));
 $("spf").innerHTML=recordList(data.spf);$("dkim").innerHTML=recordList(data.dkim.map(x=>x.selector+" · "+x.record))+`<p class="muted">${esc(data.dkim_disclaimer)}</p>`;
 $("dmarc").innerHTML=recordList(data.dmarc);
 $("checks").innerHTML=data.checks.map(c=>`<div class="check"><span class="status ${c.status}">${c.status}</span><b>${esc(c.name)}</b><div class="muted">${esc(c.detail)}</div></div>`).join("");
 $("recommendations").innerHTML=data.recommendations.map(x=>`<li>${esc(x)}</li>`).join("");
 $("results").scrollIntoView({behavior:"smooth",block:"start"});
}
$("analyze").onclick=async()=>{
 $("error").textContent="";let target=$("target").value.trim();if(!target){$("error").textContent="Enter an email address or domain.";return}
 $("progress").classList.remove("hidden");$("analyze").disabled=true;
 try{let fd=new FormData();fd.append("target",target);let r=await fetch("/api/analyze",{method:"POST",body:fd});let d=await r.json();if(!r.ok)throw Error(d.error||"Analysis failed");render(d)}
 catch(e){$("error").textContent=e.message}finally{$("progress").classList.add("hidden");$("analyze").disabled=false}
};
$("target").addEventListener("keydown",e=>{if(e.key==="Enter")$("analyze").click()});
$("pdf").onclick=async()=>{if(!latest)return;let r=await fetch("/api/report",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(latest)});let blob=await r.blob();let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="email_security_report.pdf";a.click();URL.revokeObjectURL(a.href)};
$("emlbtn").onclick=async()=>{let f=$("eml").files[0];if(!f){$("emlresult").textContent="Choose an .eml file first.";return}let fd=new FormData();fd.append("eml",f);let r=await fetch("/api/analyze-eml",{method:"POST",body:fd});let d=await r.json();if(!r.ok){$("emlresult").textContent=d.error;return}
 $("emlresult").innerHTML=`<b>Risk: ${esc(d.risk)}</b><p>From: ${esc(d.from)}<br>Reply-To: ${esc(d.reply_to)}<br>Return-Path: ${esc(d.return_path)}<br>Received hops: ${d.received_hops}</p><b>Authentication-Results</b><pre>${esc(d.authentication_results)}</pre><b>Findings</b><ul>${d.findings.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><p class="muted">${esc(d.disclaimer)}</p>`;
};
