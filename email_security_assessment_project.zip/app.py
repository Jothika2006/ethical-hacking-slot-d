import os, re, io, json, secrets, smtplib, ssl
from datetime import datetime, timezone
from email import policy
from email.parser import BytesParser
from flask import Flask, render_template, request, jsonify, send_file, session
import dns.resolver
import dns.exception
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-local-demo-secret")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024

COMMON_DKIM_SELECTORS = [
    "default", "selector1", "selector2", "google", "google1", "google2",
    "k1", "s1", "s2", "dkim", "mail", "email", "smtp", "mandrill",
    "everlytickey1", "everlytickey2", "sendgrid", "zoho", "protonmail"
]

def query_txt(name):
    try:
        answers = dns.resolver.resolve(name, "TXT", lifetime=4)
        values = []
        for r in answers:
            values.append("".join(part.decode("utf-8", "replace") if isinstance(part, bytes) else str(part) for part in r.strings))
        return values, None
    except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
        return [], "No record found"
    except Exception as e:
        return [], f"Lookup unavailable: {type(e).__name__}"

def lookup(domain):
    domain = domain.lower().strip().strip(".")
    if not re.fullmatch(r"(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}", domain):
        raise ValueError("Enter a valid domain name or email address.")
    result = {"domain": domain, "checked_at": datetime.now(timezone.utc).isoformat(), "mx": [], "spf": [], "dmarc": [], "dkim": [], "notes": []}
    try:
        mx = dns.resolver.resolve(domain, "MX", lifetime=4)
        result["mx"] = [{"priority": r.preference, "host": str(r.exchange).rstrip(".")} for r in sorted(mx, key=lambda x:x.preference)]
    except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer):
        result["notes"].append("No MX records were returned. The domain may not receive email.")
    except Exception as e:
        result["notes"].append("MX lookup unavailable: " + type(e).__name__)

    txt, err = query_txt(domain)
    result["spf"] = [x for x in txt if x.lower().startswith("v=spf1")]
    result["spf_error"] = err
    dmarc, derr = query_txt("_dmarc." + domain)
    result["dmarc"] = [x for x in dmarc if x.lower().startswith("v=dmarc1")]
    result["dmarc_error"] = derr

    # DKIM selectors are not globally enumerable through standard DNS.
    for selector in COMMON_DKIM_SELECTORS:
        records, _ = query_txt(f"{selector}._domainkey.{domain}")
        for record in records:
            if "v=dkim1" in record.lower() or "p=" in record.lower():
                result["dkim"].append({"selector": selector, "record": record})
    result["dkim_checked_selectors"] = COMMON_DKIM_SELECTORS
    result["dkim_disclaimer"] = "DKIM selectors are not discoverable by a standard public DNS enumeration. These are common selector guesses only; no result does not prove DKIM is absent."

    # Score is evidence-based and explainable, not a mailbox or message-authentication test.
    score, checks = 0, []
    if result["mx"]:
        score += 15; checks.append({"name":"MX records", "status":"PASS", "detail":f'{len(result["mx"])} mail exchanger(s) found.', "points":15})
    else:
        checks.append({"name":"MX records", "status":"FAIL", "detail":"No MX records found or lookup failed.", "points":0})
    if len(result["spf"]) == 1:
        spf = result["spf"][0].lower()
        if "-all" in spf:
            score += 25; checks.append({"name":"SPF", "status":"PASS", "detail":"One SPF record found with a strict -all policy.", "points":25})
        elif "~all" in spf:
            score += 18; checks.append({"name":"SPF", "status":"WARNING", "detail":"SPF uses ~all (softfail), not a strict rejection policy.", "points":18})
        else:
            score += 10; checks.append({"name":"SPF", "status":"WARNING", "detail":"SPF exists, but its ending policy is not -all or ~all.", "points":10})
    elif len(result["spf"]) > 1:
        checks.append({"name":"SPF", "status":"FAIL", "detail":"Multiple SPF records detected; this commonly causes SPF PermError.", "points":0})
    else:
        checks.append({"name":"SPF", "status":"FAIL", "detail":"No SPF TXT record found at the domain.", "points":0})
    if len(result["dmarc"]) == 1:
        dmarc_policy = re.search(r"(?i)(?:^|;)\\s*p\\s*=\\s*(none|quarantine|reject)", result["dmarc"][0])
        policy_value = dmarc_policy.group(1).lower() if dmarc_policy else "unknown"
        if policy_value == "reject":
            score += 30; status, detail = "PASS", "DMARC policy is reject."
        elif policy_value == "quarantine":
            score += 24; status, detail = "PASS", "DMARC policy is quarantine."
        elif policy_value == "none":
            score += 12; status, detail = "WARNING", "DMARC is monitoring-only (p=none)."
        else:
            score += 5; status, detail = "WARNING", "DMARC record exists but policy could not be interpreted."
        checks.append({"name":"DMARC", "status":status, "detail":detail, "points":score if False else (30 if policy_value=="reject" else 24 if policy_value=="quarantine" else 12 if policy_value=="none" else 5)})
    else:
        checks.append({"name":"DMARC", "status":"FAIL", "detail":"No valid DMARC record found at _dmarc."+domain, "points":0})
    if result["dkim"]:
        score += 20; checks.append({"name":"DKIM discovery", "status":"PASS", "detail":f'{len(result["dkim"])} matching record(s) found among common selectors.', "points":20})
    else:
        checks.append({"name":"DKIM discovery", "status":"WARNING", "detail":"No record found among tested common selectors. Selector unknown; DKIM status is inconclusive.", "points":0})
    result["score"] = min(score, 100)
    result["checks"] = checks
    result["overall"] = "STRONG" if score >= 80 else "MODERATE" if score >= 50 else "WEAK"
    result["recommendations"] = []
    if not result["spf"]: result["recommendations"].append("Publish one SPF TXT record listing every legitimate sending service. Avoid multiple SPF records.")
    elif len(result["spf"]) > 1: result["recommendations"].append("Merge SPF mechanisms into exactly one SPF record; multiple SPF records can cause PermError.")
    elif "~all" in result["spf"][0].lower(): result["recommendations"].append("After validating all legitimate senders, consider moving SPF from ~all to -all.")
    if not result["dmarc"]: result["recommendations"].append("Publish a DMARC record at _dmarc."+domain+"; begin with p=none and rua reporting, then move toward quarantine/reject after reviewing reports.")
    elif "p=none" in result["dmarc"][0].lower(): result["recommendations"].append("Review DMARC aggregate reports and progress from p=none to quarantine/reject when legitimate senders pass alignment.")
    if not result["dkim"]: result["recommendations"].append("Enable DKIM signing with your mail provider and obtain its exact selector; verify selector._domainkey."+domain+".")
    result["recommendations"].append("Inventory all third-party senders, enable MFA for mail accounts, and monitor DMARC reports. DNS presence alone does not authenticate a specific message or prove mailbox ownership.")
    return result

@app.route("/")
def index():
    return render_template("index.html")

@app.post("/api/analyze")
def analyze():
    raw = (request.form.get("target") or "").strip()
    if "@" in raw:
        if raw.count("@") != 1 or not re.fullmatch(r"[^\\s@]+@[^\\s@]+", raw):
            return jsonify(error="Enter a valid email address or domain."), 400
        domain = raw.rsplit("@", 1)[1]
    else:
        domain = raw
    try:
        return jsonify(lookup(domain))
    except ValueError as e:
        return jsonify(error=str(e)), 400

@app.post("/api/analyze-eml")
def analyze_eml():
    f = request.files.get("eml")
    if not f or not f.filename.lower().endswith(".eml"):
        return jsonify(error="Upload an .eml email file."), 400
    try:
        msg = BytesParser(policy=policy.default).parsebytes(f.read())
        auth = str(msg.get("Authentication-Results", "Not present"))
        from_h = str(msg.get("From", "Not present"))
        reply = str(msg.get("Reply-To", "Not present"))
        return_path = str(msg.get("Return-Path", "Not present"))
        received = msg.get_all("Received", [])
        findings = []
        if auth == "Not present": findings.append("No Authentication-Results header was found; authentication cannot be confirmed from this file.")
        for token in ["spf=fail", "dkim=fail", "dmarc=fail", "spf=softfail"]:
            if token in auth.lower(): findings.append("Authentication header contains " + token + ".")
        if reply != "Not present" and from_h != "Not present" and reply.lower() not in from_h.lower():
            findings.append("Reply-To differs from the visible From address; verify this is expected.")
        risk = "HIGH RISK" if any(x in auth.lower() for x in ["spf=fail","dkim=fail","dmarc=fail"]) else "SUSPICIOUS" if findings else "UNDETERMINED"
        return jsonify({"from":from_h, "reply_to":reply, "return_path":return_path, "authentication_results":auth,
                        "received_hops":len(received), "risk":risk, "findings":findings or ["No obvious warning detected in the parsed headers. This is not proof that the message is safe."],
                        "disclaimer":"Email headers can be forged outside trusted receiving infrastructure. Treat Authentication-Results as trustworthy only when added by your own trusted mail provider."})
    except Exception as e:
        return jsonify(error="Could not parse email: "+str(e)), 400

@app.post("/api/report")
def report():
    data = request.get_json(force=True)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    story = [Paragraph("Email Security Assessment Report", styles["Title"]), Spacer(1,12),
             Paragraph("Domain: "+str(data.get("domain","")), styles["Heading2"]),
             Paragraph("Generated: "+datetime.now().strftime("%Y-%m-%d %H:%M:%S"), styles["Normal"]), Spacer(1,12),
             Paragraph("Security score: "+str(data.get("score",0))+"/100 ("+str(data.get("overall",""))+")", styles["Heading2"])]
    rows = [["Control","Status","Finding"]]
    for c in data.get("checks",[]): rows.append([c["name"],c["status"],c["detail"]])
    t=Table(rows, colWidths=[100,70,340], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#172554")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.grey),("VALIGN",(0,0),(-1,-1),"TOP"),("FONTSIZE",(0,0),(-1,-1),8),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.whitesmoke,colors.white])]))
    story += [t, Spacer(1,14), Paragraph("MX records",styles["Heading2"])]
    for mx in data.get("mx",[]): story.append(Paragraph(f'{mx["priority"]} — {mx["host"]}',styles["Normal"]))
    story.append(Paragraph("SPF records",styles["Heading2"]))
    for x in data.get("spf",[]): story.append(Paragraph(x,styles["Code"]))
    story.append(Paragraph("DMARC records",styles["Heading2"]))
    for x in data.get("dmarc",[]): story.append(Paragraph(x,styles["Code"]))
    story.append(Paragraph("DKIM discovery",styles["Heading2"]))
    story.append(Paragraph(data.get("dkim_disclaimer",""),styles["Normal"]))
    story.append(Paragraph("Recommendations",styles["Heading2"]))
    for x in data.get("recommendations",[]): story.append(Paragraph("• "+x,styles["Normal"]))
    story.append(Spacer(1,12))
    story.append(Paragraph("Limitations: This is a passive DNS-based assessment. It does not prove mailbox ownership, authenticate a particular email, guarantee deliverability, or replace a full mail-server audit. DKIM selector guesses are not exhaustive.",styles["Italic"]))
    doc.build(story); buf.seek(0)
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name="email_security_report.pdf")

@app.post("/api/otp/request")
def otp_request():
    # Real OTP delivery requires SMTP credentials supplied by the project operator.
    required = ["SMTP_HOST","SMTP_PORT","SMTP_USER","SMTP_PASSWORD","SMTP_FROM"]
    if not all(os.environ.get(k) for k in required):
        return jsonify(error="OTP is disabled. Configure SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD and SMTP_FROM in environment variables."), 501
    address=(request.json or {}).get("email","").strip()
    if not re.fullmatch(r"[^\\s@]+@[^\\s@]+",address): return jsonify(error="Valid email address required."),400
    code=f"{secrets.randbelow(1000000):06d}"
    try:
        with smtplib.SMTP(os.environ["SMTP_HOST"],int(os.environ["SMTP_PORT"]),timeout=10) as s:
            s.starttls(context=ssl.create_default_context()); s.login(os.environ["SMTP_USER"],os.environ["SMTP_PASSWORD"])
            s.sendmail(os.environ["SMTP_FROM"],[address],f"Subject: Email ownership verification OTP\\n\\nYour one-time code is {code}. It expires in 5 minutes.")
        session["otp"]={"code":code,"email":address,"expires":datetime.now().timestamp()+300}
        return jsonify(message="OTP sent. Check the mailbox.")
    except Exception as e: return jsonify(error="OTP delivery failed: "+type(e).__name__),502

@app.post("/api/otp/verify")
def otp_verify():
    item=session.get("otp",{}); body=request.json or {}
    if not item or datetime.now().timestamp()>item.get("expires",0): return jsonify(error="OTP expired or not requested."),400
    if body.get("email")!=item.get("email") or body.get("code")!=item.get("code"): return jsonify(error="Incorrect email or OTP."),400
    session.pop("otp",None)
    return jsonify(message="Mailbox access demonstrated by successful OTP delivery and response.")

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
